<?php
define('DT_REWRITE', true);
$moduleid = 18;
require '../common.inc.php';
require DT_ROOT.'/module/'.$module.'/fans.inc.php';
?>