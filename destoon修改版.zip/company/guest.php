<?php
$moduleid = 4;
require '../common.inc.php';
require DT_ROOT.'/module/'.$module.'/guest.inc.php';
?>