<?php
$moduleid = 4;
require '../common.inc.php';
require DT_ROOT.'/module/'.$module.'/home.inc.php';
?>