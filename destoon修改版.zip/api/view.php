<?php
$moduleid = 3;
require '../common.inc.php';
require DT_ROOT.'/module/'.$module.'/view.inc.php';
?>