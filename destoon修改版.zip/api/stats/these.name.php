<?php
$names = array (
  'baidu' => '百度统计(tongji.baidu.com)',
  'qq' => '腾讯分析(ta.qq.com)',
  'cnzz' => '站长统计(www.cnzz.com)',
  '51la' => '我要啦(www.51.la)',
);
?>