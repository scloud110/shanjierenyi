<?php
$_CACHE['apps'] = array ();
?>