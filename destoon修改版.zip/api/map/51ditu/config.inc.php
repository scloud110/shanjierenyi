<?php
#http://api.51ditu.com/docs/index.html
$map_mid = '11640969,3989945';
$map_key = '';
?>