<?php
#http://open.map.qq.com/doc_v2/example.html
$map_mid = '39.916527,116.397128';
$map_key = '';
?>