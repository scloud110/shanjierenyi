<?php
define('DT_REWRITE', true);
$moduleid = 13;
require '../common.inc.php';
require DT_ROOT.'/module/'.$module.'/message.inc.php';
?>