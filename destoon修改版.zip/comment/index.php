<?php
define('DT_REWRITE', true);
$moduleid = 3;
require '../common.inc.php';
require DT_ROOT.'/module/'.$module.'/comment.inc.php';
?>